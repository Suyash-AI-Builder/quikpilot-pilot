# @quikit/quikpilot-runner

QuikPilot's CI runner. Invoked automatically by the `.github/workflows/quikpilot.yml` file QuikPilot
installs in an onboarded repository — it fetches the run's work packet, runs your setup/lint/test
commands, reports results to QuikTest, enforces the denied-path guardrail, commits, pushes, and
reports back to QuikTrack.

This package is not meant to be installed or run by hand. It exists so a fix to QuikPilot's runner
logic ships as a new package version rather than a new pull request into every onboarded repository
— the workflow file itself lives in your repository (QuikIT cannot update it directly), so it stays a
thin, ~25-line launcher that invokes an exact, pinned version of this package via `npx`.

It carries no secrets and needs none of your credentials: it authenticates to QuikTrack and to GitHub
using short-lived tokens exchanged at runtime, never a value baked into the workflow file or this
package.

## Versioning and support

Every workflow file pins an **exact** version of this package (`npx --yes
@quikit/quikpilot-runner@<version>`, never a range or `latest`) — a repository never picks up a new
release on its own. Older published versions are not removed from npm and keep working as long as a
repository's workflow file keeps pinning them; upgrading to a newer version only happens through a new
pull request into that repository (QuikTrack's "re-bootstrap" flow), never silently.

Releases follow [SemVer](https://semver.org/): a major version bump means the workflow file's own
shape changed (inputs, permissions) and requires a new pull request regardless of this package's
version; minor/patch releases are runner-logic fixes safe to pick up on the next re-bootstrap.
